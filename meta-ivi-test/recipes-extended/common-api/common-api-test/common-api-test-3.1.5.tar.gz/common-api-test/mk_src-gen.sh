#!/bin/sh
for i in `find . -maxdepth 1 -type d | sort | awk -F/ '{print $2}'`; do
  echo $i
  cd $i

  rm -rf src-gen
  ../../commonapi-generator/commonapi-generator-linux-x86_64 -sk fidl/*.fidl 
  mkdir src-gen/core
  if [ -d src-gen/v? ]; then
    mv src-gen/v?/ src-gen/core/
  else
    mv src-gen/commonapi/ src-gen/core/
  fi
  
  ../../commonapi_dbus_generator/commonapi-dbus-generator-linux-x86_64 fidl/*.fidl 
  mkdir src-gen/dbus
  if [ -d src-gen/v? ]; then
    mv src-gen/v?/ src-gen/dbus/
  else
    mv src-gen/commonapi/ src-gen/dbus/
  fi

  cd ..
done