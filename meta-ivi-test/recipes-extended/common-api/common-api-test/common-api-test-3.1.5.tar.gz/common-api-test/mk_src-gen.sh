../../commonapi-generator/commonapi-generator-linux-x86_64 -sk fidl/*.fidl 
mkdir src-gen/core
if [ -d src-gen/v1 ]; then
  mv src-gen/v1/ src-gen/core/
else
  mv src-gen/commonapi/ src-gen/core/
fi

../../commonapi_dbus_generator/commonapi-dbus-generator-linux-x86_64 fidl/*.fidl 
mkdir src-gen/dbus
if [ -d src-gen/v1 ]; then
  mv src-gen/v1/ src-gen/dbus/
else
  mv src-gen/commonapi/ src-gen/dbus/
fi
