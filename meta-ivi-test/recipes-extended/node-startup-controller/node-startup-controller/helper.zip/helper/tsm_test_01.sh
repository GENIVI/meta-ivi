#!/bin/sh
source /opt/tests/node-startup-controller/helper.sh

systemctl stop node-startup-controller.service
systemctl stop nsm-dummy.service
sleep 1

systemctl start nsm-dummy.service
systemctl start node-startup-controller.service

sleep 2
get_log "Node state 2 applied"
