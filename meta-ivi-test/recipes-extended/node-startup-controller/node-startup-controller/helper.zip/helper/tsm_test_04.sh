#!/bin/sh
source /opt/tests/node-startup-controller/helper.sh

systemctl start lazy.target
systemctl start lazy.target

sleep 2
get_log "Node state 5 applied"
