#!/bin/sh
source /opt/tests/node-startup-controller/helper.sh

systemctl start unfocussed.target
systemctl start unfocussed.target

sleep 2
get_log "Node state 4 applied"
