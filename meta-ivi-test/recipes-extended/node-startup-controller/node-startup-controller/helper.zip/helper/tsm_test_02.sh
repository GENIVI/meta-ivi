#!/bin/sh
source /opt/tests/node-startup-controller/helper.sh

systemctl start focussed.target
systemctl start focussed.target

sleep 2
get_log "Node state 3 applied"
