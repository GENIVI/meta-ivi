#!/bin/sh
source /opt/tests/node-startup-controller/helper.sh

systemctl stop focussed.target

sleep 2
get_log "Creating D-Bus proxy|Active state of unit"
