#!/bin/sh

# function to begin registration
begin()
{
  gdbus call --system \
    -d org.genivi.NodeStartupController1 \
    -o /org/genivi/NodeStartupController1/NodeStartupController \
    -m org.genivi.NodeStartupController1.NodeStartupController.BeginLUCRegistration
}

# function to make a registration call
register()
{
  gdbus call --system \
    -d org.genivi.NodeStartupController1 \
    -o /org/genivi/NodeStartupController1/NodeStartupController \
    -m org.genivi.NodeStartupController1.NodeStartupController.RegisterWithLUC \
    "$1"
}

# function to finish registration
end()
{
  gdbus call --system \
    -d org.genivi.NodeStartupController1 \
    -o /org/genivi/NodeStartupController1/NodeStartupController \
    -m org.genivi.NodeStartupController1.NodeStartupController.FinishLUCRegistration
}

# function to filter messages
DATE=`date +"%Y/%m/%d %H:%M"`
get_log() {
   dlt-convert -a /tmp/dlt_receive_log.dlt | grep "${DATE}" | grep -E "$1"
}

get_log_no_date() {
   dlt-convert -a /tmp/dlt_receive_log.dlt | grep -E "$1"
}
