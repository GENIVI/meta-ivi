#!/bin/sh
source /opt/tests/node-startup-controller/helper.sh

echo ${DATE}
get_log_no_date "LUC is not required"
