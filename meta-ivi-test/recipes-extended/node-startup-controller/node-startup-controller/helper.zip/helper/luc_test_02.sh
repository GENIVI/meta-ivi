#!/bin/sh
source /opt/tests/node-startup-controller/helper.sh

register "{1: ['app2.unit']}"
sleep 1
systemctl restart node-startup-controller.service
systemctl restart node-startup-controller.service

sleep 1
get_log "Starting LUC|Finished starting LUC"
