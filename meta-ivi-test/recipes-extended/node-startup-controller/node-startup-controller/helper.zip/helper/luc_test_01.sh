#!/bin/sh
source /opt/tests/node-startup-controller/helper.sh

begin
register "{0: ['app1.unit']}"
end
sleep 1
systemctl restart node-startup-controller.service
systemctl restart node-startup-controller.service

sleep 1
get_log "Updated LUC|Starting LUC|Finished starting LUC"
