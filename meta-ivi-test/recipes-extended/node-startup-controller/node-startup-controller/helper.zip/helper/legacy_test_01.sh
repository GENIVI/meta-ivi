#!/bin/sh
source /opt/tests/node-startup-controller/helper.sh

kill -s HUP $(pidof nsm-dummy)

sleep 2
get_log "Shutdown client|Successfully"
