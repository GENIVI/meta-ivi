#!/bin/sh
source /opt/tests/node-startup-controller/helper.sh

LAH=/usr/lib/node-startup-controller-1/legacy-app-handler
${LAH} --unit
${LAH} --unit "hello.service" -m 0
${LAH} --unit "hello.service" -m 1 -t -2000
kill -s HUP $(pidof nsm-dummy)

sleep 2
get_log "Failed to parse|Failed to register"
