#!/bin/sh
source /opt/tests/node-startup-controller/helper.sh

LAH=/usr/lib/node-startup-controller-1/legacy-app-handler
${LAH} --unit "hello.service" -m 1
${LAH} --unit "example.service" -m 1
kill -s HUP $(pidof nsm-dummy)

sleep 2
get_log "Shutdown client|Shutting down a client|Completing a lifecycle"
